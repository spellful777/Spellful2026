import{a as o}from"./query-BlM6LSDH.js";import{R as t,T as r,V as s}from"./index-aZbRtLR2.js";function i(){!t.current&&r();const[e]=o.useState(s.current);return e}export{i as u};
