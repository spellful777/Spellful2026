import{a as o}from"./query-BlM6LSDH.js";import{P as t,Q as r,R as s}from"./index-D3d1x8xh.js";function i(){!t.current&&r();const[e]=o.useState(s.current);return e}export{i as u};
