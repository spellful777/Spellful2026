import{a as o}from"./query-BlM6LSDH.js";import{I as t,J as r,K as s}from"./index-B0zUjqZQ.js";function i(){!t.current&&r();const[e]=o.useState(s.current);return e}export{i as u};
