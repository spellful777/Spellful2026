import{a as o}from"./query-BlM6LSDH.js";import{R as t,T as r,V as s}from"./index-Bk5vS6UG.js";function i(){!t.current&&r();const[e]=o.useState(s.current);return e}export{i as u};
