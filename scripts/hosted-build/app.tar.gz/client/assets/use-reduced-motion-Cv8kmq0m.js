import{a as o}from"./query-BlM6LSDH.js";import{O as t,P as r,Q as s}from"./index-BgMXyzEd.js";function i(){!t.current&&r();const[e]=o.useState(s.current);return e}export{i as u};
